declare module "*.vue" {
    import Vue from 'vue'
    export default typeof Vue
}
