﻿# The example of creating new question type: "date", based on jQuery UI date widget.

##To include the plugin into the bundle

 1. Rename the file "./knockout/template/question_date.html_" to "./knockout/template/question_date.html".
 2. Uncomment the last line in files: "$root/src/entries/chunks/model.ts", "$root/src/entries/ko.ts" and "$root/src/entries/react.ts"
 3. Rebuild the library using the instruction in the README.md file of this repo.
