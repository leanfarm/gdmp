export * from "./react";
export {SurveyNG} from "../angular/SurveyNG";
export {SurveyWindowNG} from "../angular/SurveyNG";
