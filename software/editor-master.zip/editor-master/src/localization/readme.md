Make a pull request of your localized version of defaultStrigns export var in https://github.com/surveyjs/editor/blob/master/src/editorLocalization.ts.

Name it as [language name].ts, for example: french.ts