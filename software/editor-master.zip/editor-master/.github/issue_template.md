### Are you requesting a feature, reporting a bug or ask a queation?



### What is the current behavior?



### What is the expected behavior?



### How would you reproduce the current behavior (if this is a bug)?



#### Provide the test code and the tested page URL (if applicable)

Tested page URL:

Test code

```
your_code_here

```

### Specify your

* browser:
* editor version:
