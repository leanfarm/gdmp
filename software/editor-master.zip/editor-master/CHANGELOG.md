# Change Log

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

<a name="0.12.15"></a>
## [0.12.15](https://github.com/surveyjs/editor/compare/v0.12.14...v0.12.15) (2017-05-19)



<a name="0.12.14"></a>
## [0.12.14](https://github.com/surveyjs/editor/compare/v0.12.13...v0.12.14) (2017-05-11)



<a name="0.12.13"></a>
## [0.12.13](https://github.com/surveyjs/editor/compare/v0.12.12...v0.12.13) (2017-05-10)



<a name="0.12.12"></a>
## [0.12.12](https://github.com/surveyjs/editor/compare/v0.12.11...v0.12.12) (2017-05-03)



<a name="0.12.11"></a>
## [0.12.11](https://github.com/surveyjs/editor/compare/v0.12.10...v0.12.11) (2017-04-24)



<a name="0.12.10"></a>
## [0.12.10](https://github.com/surveyjs/editor/compare/v0.12.9...v0.12.10) (2017-04-20)



<a name="0.12.9"></a>
## [0.12.9](https://github.com/surveyjs/editor/compare/v0.12.8...v0.12.9) (2017-04-17)



<a name="0.12.8"></a>
## [0.12.8](https://github.com/surveyjs/editor/compare/v0.12.7...v0.12.8) (2017-04-13)



<a name="0.12.7"></a>
## [0.12.7](https://github.com/surveyjs/editor/compare/v0.12.6...v0.12.7) (2017-04-10)



<a name="0.12.6"></a>
## [0.12.6](https://github.com/surveyjs/editor/compare/v0.12.5...v0.12.6) (2017-04-05)



<a name="0.12.5"></a>
## [0.12.5](https://github.com/surveyjs/editor/compare/v0.12.4...v0.12.5) (2017-03-27)



<a name="0.12.4"></a>
## [0.12.4](https://github.com/surveyjs/editor/compare/v0.12.3...v0.12.4) (2017-03-17)
